import os
from datetime import datetime, timedelta
from functools import wraps

from flask import Flask, jsonify, request, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

ROOT = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT")
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "DATABASE_URL", "sqlite:///" + os.path.join(ROOT, "nexstudy.db")
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
db = SQLAlchemy(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="student")
    phone = db.Column(db.String(30))
    college = db.Column(db.String(180), nullable=False)
    enrollment = db.Column(db.String(80))
    course = db.Column(db.String(120))
    semester = db.Column(db.String(80))
    department = db.Column(db.String(120))
    faculty_id = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def public(self):
        return {k: getattr(self, k) for k in (
            "id", "name", "email", "role", "phone", "college",
            "enrollment", "course", "semester", "department", "faculty_id"
        )}


class ClassRoom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    course = db.Column(db.String(120), nullable=False)
    semester = db.Column(db.String(80))
    section = db.Column(db.String(50))
    description = db.Column(db.Text)
    faculty_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("class_room.id"), nullable=False)
    __table_args__ = (db.UniqueConstraint("user_id", "class_id"),)


class Assignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    subject = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    deadline = db.Column(db.DateTime, nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("class_room.id"), nullable=False)
    faculty_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(db.Integer, db.ForeignKey("assignment.id"), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    answer_text = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint("assignment_id", "student_id"),)


class CommunityPost(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("class_room.id"))
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class SeniorCard(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    topic = db.Column(db.String(180), nullable=False)
    course = db.Column(db.String(120), nullable=False)
    bio = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Quiz(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(180), nullable=False)
    question = db.Column(db.Text, nullable=False)
    options_json = db.Column(db.JSON, nullable=False)
    correct_index = db.Column(db.Integer, nullable=False)
    explanation = db.Column(db.Text)
    deadline = db.Column(db.DateTime, nullable=False)
    class_id = db.Column(db.Integer, db.ForeignKey("class_room.id"), nullable=False)
    faculty_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)


class QuizAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quiz_id = db.Column(db.Integer, db.ForeignKey("quiz.id"), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    selected_index = db.Column(db.Integer, nullable=False)
    is_correct = db.Column(db.Boolean, nullable=False)
    points = db.Column(db.Integer, default=0)
    attempted_at = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint("quiz_id", "student_id"),)


def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not current_user():
            return jsonify(error="Authentication required"), 401
        return fn(*args, **kwargs)
    return wrapped


def faculty_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            return jsonify(error="Authentication required"), 401
        if user.role != "faculty":
            return jsonify(error="Faculty access required"), 403
        return fn(*args, **kwargs)
    return wrapped


def dt(value):
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def class_json(c):
    return {"id": c.id, "name": c.name, "course": c.course, "semester": c.semester,
            "section": c.section, "description": c.description}


def assignment_json(a, user_id=None):
    c = db.session.get(ClassRoom, a.class_id)
    submitted = False
    if user_id:
        submitted = Submission.query.filter_by(assignment_id=a.id, student_id=user_id).first() is not None
    return {"id": a.id, "title": a.title, "subject": a.subject, "description": a.description,
            "deadline": a.deadline.isoformat(), "class_id": a.class_id,
            "class_name": c.name if c else "", "submitted": submitted}


@app.get("/")
def home():
    return send_from_directory("templates", "index.html")


@app.get("/api/health")
def health():
    return jsonify(status="ok", service="NEXSTUDY API")


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    required = ["name", "email", "password", "college", "role"]
    if any(not str(data.get(k, "")).strip() for k in required):
        return jsonify(error="Please complete all required fields"), 400
    role = data["role"].lower()
    if role not in ("student", "faculty"):
        return jsonify(error="Invalid account role"), 400
    password = data["password"]
    if len(password) < 8:
        return jsonify(error="Password must contain at least 8 characters"), 400
    email = data["email"].strip().lower()
    if User.query.filter_by(email=email).first():
        return jsonify(error="An account with this email already exists"), 409
    user = User(
        name=data["name"].strip(), email=email,
        password_hash=generate_password_hash(password), role=role,
        phone=data.get("phone", "").strip(), college=data["college"].strip(),
        enrollment=data.get("enrollment"), course=data.get("course"),
        semester=data.get("semester"), department=data.get("department"),
        faculty_id=data.get("faculty_id")
    )
    db.session.add(user)
    db.session.commit()
    session.clear()
    session["user_id"] = user.id
    return jsonify(user=user.public()), 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    user = User.query.filter_by(email=str(data.get("email", "")).strip().lower()).first()
    if not user or not check_password_hash(user.password_hash, str(data.get("password", ""))):
        return jsonify(error="Incorrect email or password"), 401
    session.clear()
    session["user_id"] = user.id
    return jsonify(user=user.public())


@app.post("/api/logout")
@login_required
def logout():
    session.clear()
    return jsonify(message="Logged out")


@app.get("/api/me")
@login_required
def me():
    return jsonify(user=current_user().public())


@app.patch("/api/profile")
@login_required
def update_profile():
    user = current_user()
    data = request.get_json(silent=True) or {}
    allowed = ["name", "phone", "college", "enrollment", "course", "semester", "department", "faculty_id"]
    for key in allowed:
        if key in data:
            setattr(user, key, str(data[key]).strip())
    db.session.commit()
    return jsonify(user=user.public())


@app.get("/api/classes")
@login_required
def list_classes():
    user = current_user()
    if user.role == "faculty":
        rows = ClassRoom.query.filter_by(faculty_id=user.id).order_by(ClassRoom.created_at.desc()).all()
    else:
        ids = [e.class_id for e in Enrollment.query.filter_by(user_id=user.id).all()]
        rows = ClassRoom.query.filter(ClassRoom.id.in_(ids)).all() if ids else []
    return jsonify(classes=[class_json(c) for c in rows])


@app.post("/api/classes")
@faculty_required
def create_class():
    d = request.get_json(silent=True) or {}
    if not d.get("name") or not d.get("course"):
        return jsonify(error="Class name and course are required"), 400
    c = ClassRoom(name=d["name"].strip(), course=d["course"].strip(),
                  semester=d.get("semester"), section=d.get("section"),
                  description=d.get("description"), faculty_id=current_user().id)
    db.session.add(c)
    db.session.commit()
    return jsonify(classroom=class_json(c)), 201


@app.post("/api/classes/<int:class_id>/enroll")
@faculty_required
def enroll_student(class_id):
    d = request.get_json(silent=True) or {}
    student = User.query.filter_by(email=str(d.get("email", "")).strip().lower(), role="student").first()
    if not student:
        return jsonify(error="Student account not found"), 404
    c = ClassRoom.query.filter_by(id=class_id, faculty_id=current_user().id).first()
    if not c:
        return jsonify(error="Class not found"), 404
    if not Enrollment.query.filter_by(user_id=student.id, class_id=c.id).first():
        db.session.add(Enrollment(user_id=student.id, class_id=c.id))
        db.session.commit()
    return jsonify(message="Student enrolled")


@app.get("/api/assignments")
@login_required
def list_assignments():
    user = current_user()
    if user.role == "faculty":
        rows = Assignment.query.filter_by(faculty_id=user.id).order_by(Assignment.deadline).all()
    else:
        ids = [e.class_id for e in Enrollment.query.filter_by(user_id=user.id).all()]
        rows = Assignment.query.filter(Assignment.class_id.in_(ids)).order_by(Assignment.deadline).all() if ids else []
    return jsonify(assignments=[assignment_json(a, user.id) for a in rows])


@app.post("/api/assignments")
@faculty_required
def create_assignment():
    d = request.get_json(silent=True) or {}
    deadline = dt(d.get("deadline"))
    c = ClassRoom.query.filter_by(id=d.get("class_id"), faculty_id=current_user().id).first()
    if not d.get("title") or not d.get("subject") or not deadline or not c:
        return jsonify(error="Valid title, subject, class and deadline are required"), 400
    a = Assignment(title=d["title"].strip(), subject=d["subject"].strip(),
                   description=d.get("description", ""), deadline=deadline,
                   class_id=c.id, faculty_id=current_user().id)
    db.session.add(a)
    db.session.commit()
    return jsonify(assignment=assignment_json(a)), 201


@app.post("/api/assignments/<int:assignment_id>/submit")
@login_required
def submit_assignment(assignment_id):
    user = current_user()
    if user.role != "student":
        return jsonify(error="Only students can submit assignments"), 403
    a = db.session.get(Assignment, assignment_id)
    if not a:
        return jsonify(error="Assignment not found"), 404
    enrolled = Enrollment.query.filter_by(user_id=user.id, class_id=a.class_id).first()
    if not enrolled:
        return jsonify(error="You are not enrolled in this class"), 403
    d = request.get_json(silent=True) or {}
    sub = Submission.query.filter_by(assignment_id=a.id, student_id=user.id).first()
    if not sub:
        sub = Submission(assignment_id=a.id, student_id=user.id)
        db.session.add(sub)
    sub.answer_text = d.get("answer_text", "")
    sub.submitted_at = datetime.utcnow()
    db.session.commit()
    return jsonify(message="Assignment submitted")


@app.get("/api/community")
@login_required
def get_posts():
    user = current_user()
    ids = [e.class_id for e in Enrollment.query.filter_by(user_id=user.id).all()]
    if user.role == "faculty":
        ids = [c.id for c in ClassRoom.query.filter_by(faculty_id=user.id).all()]
    rows = CommunityPost.query.filter(CommunityPost.class_id.in_(ids)).order_by(CommunityPost.created_at.desc()).limit(100).all() if ids else []
    return jsonify(posts=[{"id": p.id, "body": p.body, "class_id": p.class_id,
                           "author": db.session.get(User, p.author_id).name,
                           "created_at": p.created_at.isoformat()} for p in rows])


@app.post("/api/community")
@login_required
def create_post():
    d = request.get_json(silent=True) or {}
    body = str(d.get("body", "")).strip()
    class_id = d.get("class_id")
    if not body or len(body) > 5000:
        return jsonify(error="Post must contain 1–5000 characters"), 400
    if class_id:
        c = db.session.get(ClassRoom, class_id)
        user = current_user()
        allowed = c and (c.faculty_id == user.id if user.role == "faculty"
                         else Enrollment.query.filter_by(user_id=user.id, class_id=c.id).first())
        if not allowed:
            return jsonify(error="You do not have access to this class"), 403
    p = CommunityPost(author_id=current_user().id, class_id=class_id, body=body)
    db.session.add(p)
    db.session.commit()
    return jsonify(message="Post published", id=p.id), 201


@app.get("/api/seniors")
@login_required
def get_seniors():
    rows = SeniorCard.query.order_by(SeniorCard.created_at.desc()).limit(100).all()
    return jsonify(cards=[{"id": x.id, "topic": x.topic, "course": x.course, "bio": x.bio,
                           "author": db.session.get(User, x.author_id).name,
                           "created_at": x.created_at.isoformat()} for x in rows])


@app.post("/api/seniors")
@login_required
def create_senior():
    d = request.get_json(silent=True) or {}
    if not all(str(d.get(k, "")).strip() for k in ("topic", "course", "bio")):
        return jsonify(error="Topic, course and introduction are required"), 400
    x = SeniorCard(author_id=current_user().id, topic=d["topic"].strip(),
                   course=d["course"].strip(), bio=d["bio"].strip())
    db.session.add(x)
    db.session.commit()
    return jsonify(message="Senior Connect card published", id=x.id), 201


@app.post("/api/quizzes")
@faculty_required
def create_quiz():
    d = request.get_json(silent=True) or {}
    c = ClassRoom.query.filter_by(id=d.get("class_id"), faculty_id=current_user().id).first()
    deadline = dt(d.get("deadline"))
    options = d.get("options")
    if not c or not deadline or not d.get("title") or not d.get("question") or not isinstance(options, list) or len(options) != 4:
        return jsonify(error="Provide a valid class, deadline, title, question and four options"), 400
    try:
        correct = int(d.get("correct_index"))
    except (TypeError, ValueError):
        return jsonify(error="Correct option must be A, B, C or D"), 400
    if correct not in range(4):
        return jsonify(error="Correct option must be A, B, C or D"), 400
    q = Quiz(title=d["title"].strip(), question=d["question"].strip(), options_json=options,
             correct_index=correct, explanation=d.get("explanation", ""),
             deadline=deadline, class_id=c.id, faculty_id=current_user().id)
    db.session.add(q)
    db.session.commit()
    return jsonify(message="Quiz published", id=q.id), 201


@app.get("/api/quizzes")
@login_required
def get_quizzes():
    user = current_user()
    ids = ([c.id for c in ClassRoom.query.filter_by(faculty_id=user.id).all()]
           if user.role == "faculty" else
           [e.class_id for e in Enrollment.query.filter_by(user_id=user.id).all()])
    rows = Quiz.query.filter(Quiz.class_id.in_(ids)).order_by(Quiz.deadline).all() if ids else []
    result = []
    for q in rows:
        attempted = QuizAttempt.query.filter_by(quiz_id=q.id, student_id=user.id).first()
        item = {"id": q.id, "title": q.title, "question": q.question,
                "options": q.options_json, "deadline": q.deadline.isoformat(),
                "class_id": q.class_id, "attempted": bool(attempted)}
        if user.role == "faculty":
            item["correct_index"] = q.correct_index
            item["explanation"] = q.explanation
        result.append(item)
    return jsonify(quizzes=result)


@app.post("/api/quizzes/<int:quiz_id>/attempt")
@login_required
def attempt_quiz(quiz_id):
    user = current_user()
    if user.role != "student":
        return jsonify(error="Only students can attempt quizzes"), 403
    q = db.session.get(Quiz, quiz_id)
    if not q:
        return jsonify(error="Quiz not found"), 404
    if q.deadline < datetime.utcnow():
        return jsonify(error="Quiz deadline has passed"), 400
    if not Enrollment.query.filter_by(user_id=user.id, class_id=q.class_id).first():
        return jsonify(error="You are not enrolled in this class"), 403
    if QuizAttempt.query.filter_by(quiz_id=q.id, student_id=user.id).first():
        return jsonify(error="You have already attempted this quiz"), 409
    d = request.get_json(silent=True) or {}
    try:
        selected = int(d.get("selected_index"))
    except (TypeError, ValueError):
        return jsonify(error="Select an option"), 400
    if selected not in range(4):
        return jsonify(error="Invalid option"), 400
    correct = selected == q.correct_index
    attempt = QuizAttempt(quiz_id=q.id, student_id=user.id, selected_index=selected,
                          is_correct=correct, points=10 if correct else 0)
    db.session.add(attempt)
    db.session.commit()
    return jsonify(correct=correct, points=attempt.points,
                   explanation=q.explanation, total_points=QuizAttempt.query.filter_by(student_id=user.id).with_entities(db.func.sum(QuizAttempt.points)).scalar() or 0)


@app.get("/api/leaderboard")
@login_required
def leaderboard():
    user = current_user()
    query = db.session.query(User.id, User.name, User.course, db.func.coalesce(db.func.sum(QuizAttempt.points), 0).label("points")).outerjoin(
        QuizAttempt, QuizAttempt.student_id == User.id
    ).filter(User.role == "student")
    if user.course:
        query = query.filter(User.course == user.course)
    rows = query.group_by(User.id).order_by(db.desc("points"), User.name).limit(50).all()
    return jsonify(leaderboard=[{"user_id": r.id, "name": r.name, "course": r.course, "points": int(r.points)} for r in rows])


@app.get("/api/dashboard")
@login_required
def dashboard():
    user = current_user()
    if user.role == "faculty":
        classes = ClassRoom.query.filter_by(faculty_id=user.id).count()
        assignments = Assignment.query.filter_by(faculty_id=user.id).count()
        return jsonify(stats={"classes": classes, "assignments": assignments})
    class_ids = [e.class_id for e in Enrollment.query.filter_by(user_id=user.id).all()]
    assignments = Assignment.query.filter(Assignment.class_id.in_(class_ids)).all() if class_ids else []
    submitted_ids = {s.assignment_id for s in Submission.query.filter_by(student_id=user.id).all()}
    points = db.session.query(db.func.coalesce(db.func.sum(QuizAttempt.points), 0)).filter_by(student_id=user.id).scalar()
    return jsonify(stats={"classes": len(class_ids), "assignments": len(assignments),
                          "submitted": len(submitted_ids), "pending": len(assignments)-len(submitted_ids),
                          "points": int(points or 0)})


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=True)
