# NEXSTUDY — Python backend

## Included
- `app.py`: Flask REST API, authentication, SQLite database and application routes.
- `templates/index.html`: your supplied NEXSTUDY HTML.
- `static/api.js`: frontend API helper.
- `requirements.txt`: Python dependencies.

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Open Command Prompt in the extracted `nexstudy_backend` folder.
4. Run:

```bash
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
py app.py
```

5. Open `http://127.0.0.1:5000`.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000`.

## Frontend connection
Your HTML currently refers to `style.css` and `script.js`, but those files were not part of the upload. Put your existing files in `static/` and update the HTML references to:

```html
<link rel="stylesheet" href="/static/style.css">
<script src="/static/api.js"></script>
<script src="/static/script.js"></script>
```

Use `window.NEXSTUDY_API` from `api.js` inside your existing frontend JavaScript. Example:

```javascript
// Login example
const result = await NEXSTUDY_API.login(email, password);
console.log(result.user);

// Load assignments
const result = await NEXSTUDY_API.assignments();
console.log(result.assignments);
```

Registration JSON example (student):

```json
{
  "name": "Student Name",
  "email": "student@example.com",
  "password": "strong-password",
  "role": "student",
  "college": "Your College",
  "phone": "9876543210",
  "enrollment": "ENR001",
  "course": "Computer Engineering",
  "semester": "1st Semester"
}
```

Faculty registration uses `role: "faculty"` and may include `department` and `faculty_id`.

## Important
- This backend creates `nexstudy.db` automatically on first run.
- Passwords are stored as secure password hashes, not plain text.
- Login uses an HTTP-only session cookie.
- Faculty-only routes enforce the faculty role on the server.
- For public deployment, set a long random `SECRET_KEY`, use HTTPS, set `COOKIE_SECURE=1`, configure a production database, and run behind a production WSGI server. Do not use Flask debug mode in production.
- The frontend's existing `script.js` must be updated to call these API methods; the HTML alone does not contain the event logic needed to connect every form and page.
- Roster PDF parsing and profile-photo upload are not implemented in this starter backend yet.
