/*
 NEXSTUDY frontend API helper.
 Include this before your existing script.js:
 <script src="/static/api.js"></script>
 <script src="/static/script.js"></script>
*/
window.NEXSTUDY_API = {
  async request(path, options = {}) {
    const response = await fetch(`/api${path}`, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  },
  register(payload) { return this.request("/register", { method: "POST", body: JSON.stringify(payload) }); },
  login(email, password) { return this.request("/login", { method: "POST", body: JSON.stringify({ email, password }) }); },
  logout() { return this.request("/logout", { method: "POST" }); },
  me() { return this.request("/me"); },
  updateProfile(payload) { return this.request("/profile", { method: "PATCH", body: JSON.stringify(payload) }); },
  dashboard() { return this.request("/dashboard"); },
  classes() { return this.request("/classes"); },
  createClass(payload) { return this.request("/classes", { method: "POST", body: JSON.stringify(payload) }); },
  assignments() { return this.request("/assignments"); },
  createAssignment(payload) { return this.request("/assignments", { method: "POST", body: JSON.stringify(payload) }); },
  submitAssignment(id, answer_text) { return this.request(`/assignments/${id}/submit`, { method: "POST", body: JSON.stringify({ answer_text }) }); },
  posts() { return this.request("/community"); },
  createPost(payload) { return this.request("/community", { method: "POST", body: JSON.stringify(payload) }); },
  seniorCards() { return this.request("/seniors"); },
  createSeniorCard(payload) { return this.request("/seniors", { method: "POST", body: JSON.stringify(payload) }); },
  quizzes() { return this.request("/quizzes"); },
  createQuiz(payload) { return this.request("/quizzes", { method: "POST", body: JSON.stringify(payload) }); },
  attemptQuiz(id, selected_index) { return this.request(`/quizzes/${id}/attempt`, { method: "POST", body: JSON.stringify({ selected_index }) }); },
  leaderboard() { return this.request("/leaderboard"); }
};
